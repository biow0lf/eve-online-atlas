-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: eve-develop
-- ------------------------------------------------------
-- Server version	5.7.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wormhole_types`
--
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wormhole_types` (
  `wormholeID` int(11) DEFAULT NULL,
  `wormholeName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `destination` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lifeTime` int(11) DEFAULT NULL,
  `jumpMass` int(11) DEFAULT NULL,
  `maxMass` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wormhole_types`
--

LOCK TABLES `wormhole_types` WRITE;
/*!40000 ALTER TABLE `wormhole_types` DISABLE KEYS */;
INSERT INTO `wormhole_types` VALUES (129,'Y790','C5','C1',16,20,500),(128,'Y683','C2','C4',16,300,2000),(127,'X877','C4','C4',16,300,2000),(126,'X702','k-space','C3',24,300,1000),(125,'W237','C6','C6',24,1350,3000),(124,'V911','C6','C5',24,1350,3000),(123,'V753','C5','C6',24,1350,3000),(122,'V301','C3','C1',16,20,500),(121,'V283','highsec','nullsec',24,1000,3000),(120,'U574','C4','C6',24,300,3000),(119,'U319','low/nullsec','C6',48,1350,3000),(118,'U210','C3','lowsec',24,300,3000),(117,'T405','C3','C4',16,300,2000),(116,'S804','C1','C6',24,20,1000),(115,'S199','C9','nullsec',24,1350,3000),(114,'S047','C4','highsec',24,300,3000),(113,'R943','k-space','C2',16,300,750),(112,'R474','C2','C6',24,300,3000),(111,'R051','highsec','lowsec',16,1000,3000),(110,'Q317','C6','C1',16,20,500),(109,'P060','C4','C1',16,20,500),(108,'O883','C1','C3',16,20,1000),(107,'O477','C2','C3',16,300,2000),(106,'O128','k-space','C4',24,300,1000),(105,'N968','C3','C3',16,300,2000),(104,'N770','C3','C5',24,300,3000),(103,'N766','C4','C2',16,300,2000),(102,'N432','low/nullsec','C5',24,1350,3000),(101,'N290','C9','lowsec',24,1350,3000),(100,'N110','C1','highsec',24,20,1000),(99,'N062','C2','C5',24,300,3000),(98,'M609','C1','C4',16,20,1000),(97,'M555','highsec','C5',24,1000,3000),(96,'M267','C5','C3',16,300,1000),(95,'L614','C1','C5',24,20,1000),(94,'L477','C6','C3',16,300,2000),(93,'K346','C3','nullsec',24,300,3000),(92,'K329','low/nullsec','nullsec',24,1800,5000),(91,'K162','anywhere','anywhere',0,0,0),(90,'J244','C1','lowsec',24,20,1000),(89,'I182','C3','C2',16,300,2000),(88,'H900','C4','C5',24,300,3000),(87,'H296','C5','C5',24,1350,3000),(86,'H121','C1','C1',16,20,500),(85,'G024','C6','C2',16,300,2000),(84,'E545','C2','nullsec',24,300,2000),(83,'E175','C5','C4',16,300,2000),(82,'D845','C3','highsec',24,300,5000),(81,'D792','C5/6','highsec',24,1000,3000),(80,'D382','C2','C2',16,300,2000),(79,'D364','C5','C2',16,300,1000),(78,'C391','low/nullsec','lowsec',24,1800,5000),(77,'C248','low/nullsec','nullsec',24,1800,5000),(76,'C247','C4','C3',16,300,2000),(75,'C140','C5/6','lowsec',24,1350,3000),(74,'C125','C1','C2',16,20,1000),(73,'B449','low/nullsec','highsec',16,1000,2000),(72,'B274','C2','highsec',24,300,2000),(71,'B041','highsec','C6',48,300,5000),(70,'A982','C3','C6',24,300,3000),(69,'A641','highsec','highsec',16,1000,2000),(68,'A239','C2','lowsec',24,300,2000),(130,'Z060','C1','nullsec',24,20,1000),(131,'Z142','C5/6','nullsec',24,1350,3000),(132,'Z457','C6','C4',16,300,2000),(133,'Z647','C2','C1',16,20,500),(134,'Z971','k-space','C1',16,20,100);
/*!40000 ALTER TABLE `wormhole_types` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-04  1:25:29
